﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GestorTablas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.AnadirSitioButton = New System.Windows.Forms.Button()
        Me.ModificarSitioButton = New System.Windows.Forms.Button()
        Me.EliminarSitioButton = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.LimpiarArtistaButton = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GestionarPaisComboBox = New System.Windows.Forms.ComboBox()
        Me.NombreArtistaTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.IdArtistaTextBox = New System.Windows.Forms.TextBox()
        Me.ArtistasListBox = New System.Windows.Forms.ListBox()
        Me.EliminarArtistaButton = New System.Windows.Forms.Button()
        Me.ModificarArtistaButton = New System.Windows.Forms.Button()
        Me.AnadirArtistaButton = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NombrePaisTextBox = New System.Windows.Forms.TextBox()
        Me.IdPaisTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PaisListBox = New System.Windows.Forms.ListBox()
        Me.EliminarPaisButton = New System.Windows.Forms.Button()
        Me.LimpiarPaisButton = New System.Windows.Forms.Button()
        Me.AnadirPaisButton = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.IdAlbumTextBox = New System.Windows.Forms.TextBox()
        Me.LimpiarAlbumButton = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ArtistaAlbumComboBox = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.AnoAlbumTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TituloAlbumTextBox = New System.Windows.Forms.TextBox()
        Me.AlbumesListBox = New System.Windows.Forms.ListBox()
        Me.EliminarAlbumButton = New System.Windows.Forms.Button()
        Me.ModificarAlbumButton = New System.Windows.Forms.Button()
        Me.AnadirAlbumButton = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.LimpiarCancionesButton = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.OrdenCancionTextBox = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.AlbumCancionComboBox = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.IdCancionTextBox = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DuracionCancionTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TituloCancionTextBox = New System.Windows.Forms.TextBox()
        Me.CancionesListBox = New System.Windows.Forms.ListBox()
        Me.EliminarCancionesButton = New System.Windows.Forms.Button()
        Me.ModificarCancionesButton = New System.Windows.Forms.Button()
        Me.AnadirCancionesButton = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.LimpiarSitiosButton = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TipoSitioTextBox = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.PaisSitioComboBox = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.IdSitioTextBox = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.NombreSitioTextBox = New System.Windows.Forms.TextBox()
        Me.SitioListBox = New System.Windows.Forms.ListBox()
        Me.ArtAlbumListbox = New System.Windows.Forms.ListBox()
        Me.NAlbumesListbox = New System.Windows.Forms.ListBox()
        Me.TabControl1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.SuspendLayout()
        '
        'AnadirSitioButton
        '
        Me.AnadirSitioButton.Location = New System.Drawing.Point(557, 4)
        Me.AnadirSitioButton.Margin = New System.Windows.Forms.Padding(2)
        Me.AnadirSitioButton.Name = "AnadirSitioButton"
        Me.AnadirSitioButton.Size = New System.Drawing.Size(145, 80)
        Me.AnadirSitioButton.TabIndex = 0
        Me.AnadirSitioButton.Text = "Añadir"
        Me.AnadirSitioButton.UseVisualStyleBackColor = True
        '
        'ModificarSitioButton
        '
        Me.ModificarSitioButton.Location = New System.Drawing.Point(557, 98)
        Me.ModificarSitioButton.Margin = New System.Windows.Forms.Padding(2)
        Me.ModificarSitioButton.Name = "ModificarSitioButton"
        Me.ModificarSitioButton.Size = New System.Drawing.Size(145, 80)
        Me.ModificarSitioButton.TabIndex = 2
        Me.ModificarSitioButton.Text = "Modificar"
        Me.ModificarSitioButton.UseVisualStyleBackColor = True
        '
        'EliminarSitioButton
        '
        Me.EliminarSitioButton.Location = New System.Drawing.Point(557, 284)
        Me.EliminarSitioButton.Margin = New System.Windows.Forms.Padding(2)
        Me.EliminarSitioButton.Name = "EliminarSitioButton"
        Me.EliminarSitioButton.Size = New System.Drawing.Size(145, 80)
        Me.EliminarSitioButton.TabIndex = 4
        Me.EliminarSitioButton.Text = "Eliminar"
        Me.EliminarSitioButton.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(394, 116)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(6, 6)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage1.Size = New System.Drawing.Size(0, 0)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage2.Size = New System.Drawing.Size(0, 0)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Location = New System.Drawing.Point(4, 2)
        Me.TabControl2.Margin = New System.Windows.Forms.Padding(2)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(800, 423)
        Me.TabControl2.TabIndex = 7
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.LimpiarArtistaButton)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.GestionarPaisComboBox)
        Me.TabPage3.Controls.Add(Me.NombreArtistaTextBox)
        Me.TabPage3.Controls.Add(Me.Label2)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Controls.Add(Me.IdArtistaTextBox)
        Me.TabPage3.Controls.Add(Me.ArtistasListBox)
        Me.TabPage3.Controls.Add(Me.EliminarArtistaButton)
        Me.TabPage3.Controls.Add(Me.ModificarArtistaButton)
        Me.TabPage3.Controls.Add(Me.AnadirArtistaButton)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage3.Size = New System.Drawing.Size(792, 397)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Artistas"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'LimpiarArtistaButton
        '
        Me.LimpiarArtistaButton.Location = New System.Drawing.Point(557, 207)
        Me.LimpiarArtistaButton.Name = "LimpiarArtistaButton"
        Me.LimpiarArtistaButton.Size = New System.Drawing.Size(145, 72)
        Me.LimpiarArtistaButton.TabIndex = 16
        Me.LimpiarArtistaButton.Text = "Limpiar"
        Me.LimpiarArtistaButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(371, 271)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "PAÍS"
        '
        'GestionarPaisComboBox
        '
        Me.GestionarPaisComboBox.FormattingEnabled = True
        Me.GestionarPaisComboBox.Location = New System.Drawing.Point(328, 294)
        Me.GestionarPaisComboBox.Margin = New System.Windows.Forms.Padding(2)
        Me.GestionarPaisComboBox.Name = "GestionarPaisComboBox"
        Me.GestionarPaisComboBox.Size = New System.Drawing.Size(120, 21)
        Me.GestionarPaisComboBox.TabIndex = 14
        '
        'NombreArtistaTextBox
        '
        Me.NombreArtistaTextBox.Location = New System.Drawing.Point(328, 211)
        Me.NombreArtistaTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.NombreArtistaTextBox.Name = "NombreArtistaTextBox"
        Me.NombreArtistaTextBox.Size = New System.Drawing.Size(120, 20)
        Me.NombreArtistaTextBox.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(361, 186)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "NOMBRE"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(341, 100)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "ID DEL ARTISTA"
        '
        'IdArtistaTextBox
        '
        Me.IdArtistaTextBox.Location = New System.Drawing.Point(328, 132)
        Me.IdArtistaTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.IdArtistaTextBox.Name = "IdArtistaTextBox"
        Me.IdArtistaTextBox.Size = New System.Drawing.Size(120, 20)
        Me.IdArtistaTextBox.TabIndex = 10
        '
        'ArtistasListBox
        '
        Me.ArtistasListBox.FormattingEnabled = True
        Me.ArtistasListBox.Location = New System.Drawing.Point(34, 41)
        Me.ArtistasListBox.Margin = New System.Windows.Forms.Padding(2)
        Me.ArtistasListBox.Name = "ArtistasListBox"
        Me.ArtistasListBox.Size = New System.Drawing.Size(163, 303)
        Me.ArtistasListBox.TabIndex = 6
        '
        'EliminarArtistaButton
        '
        Me.EliminarArtistaButton.Location = New System.Drawing.Point(557, 297)
        Me.EliminarArtistaButton.Margin = New System.Windows.Forms.Padding(2)
        Me.EliminarArtistaButton.Name = "EliminarArtistaButton"
        Me.EliminarArtistaButton.Size = New System.Drawing.Size(145, 80)
        Me.EliminarArtistaButton.TabIndex = 5
        Me.EliminarArtistaButton.Text = "Eliminar"
        Me.EliminarArtistaButton.UseVisualStyleBackColor = True
        '
        'ModificarArtistaButton
        '
        Me.ModificarArtistaButton.Location = New System.Drawing.Point(557, 114)
        Me.ModificarArtistaButton.Margin = New System.Windows.Forms.Padding(2)
        Me.ModificarArtistaButton.Name = "ModificarArtistaButton"
        Me.ModificarArtistaButton.Size = New System.Drawing.Size(145, 80)
        Me.ModificarArtistaButton.TabIndex = 3
        Me.ModificarArtistaButton.Text = "Modificar"
        Me.ModificarArtistaButton.UseVisualStyleBackColor = True
        '
        'AnadirArtistaButton
        '
        Me.AnadirArtistaButton.Location = New System.Drawing.Point(557, 18)
        Me.AnadirArtistaButton.Margin = New System.Windows.Forms.Padding(2)
        Me.AnadirArtistaButton.Name = "AnadirArtistaButton"
        Me.AnadirArtistaButton.Size = New System.Drawing.Size(145, 80)
        Me.AnadirArtistaButton.TabIndex = 1
        Me.AnadirArtistaButton.Text = "Añadir"
        Me.AnadirArtistaButton.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label5)
        Me.TabPage4.Controls.Add(Me.NombrePaisTextBox)
        Me.TabPage4.Controls.Add(Me.IdPaisTextBox)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.PaisListBox)
        Me.TabPage4.Controls.Add(Me.EliminarPaisButton)
        Me.TabPage4.Controls.Add(Me.LimpiarPaisButton)
        Me.TabPage4.Controls.Add(Me.AnadirPaisButton)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Size = New System.Drawing.Size(792, 397)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "Paises"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(347, 208)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "PAIS"
        '
        'NombrePaisTextBox
        '
        Me.NombrePaisTextBox.Location = New System.Drawing.Point(304, 233)
        Me.NombrePaisTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.NombrePaisTextBox.Name = "NombrePaisTextBox"
        Me.NombrePaisTextBox.Size = New System.Drawing.Size(116, 20)
        Me.NombrePaisTextBox.TabIndex = 10
        '
        'IdPaisTextBox
        '
        Me.IdPaisTextBox.Location = New System.Drawing.Point(304, 105)
        Me.IdPaisTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.IdPaisTextBox.Name = "IdPaisTextBox"
        Me.IdPaisTextBox.Size = New System.Drawing.Size(122, 20)
        Me.IdPaisTextBox.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(259, 77)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(222, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "ID DEL PAIS (3 LETRAS IDENTIFICATIVAS)"
        '
        'PaisListBox
        '
        Me.PaisListBox.FormattingEnabled = True
        Me.PaisListBox.Location = New System.Drawing.Point(26, 25)
        Me.PaisListBox.Margin = New System.Windows.Forms.Padding(2)
        Me.PaisListBox.Name = "PaisListBox"
        Me.PaisListBox.Size = New System.Drawing.Size(163, 329)
        Me.PaisListBox.TabIndex = 7
        '
        'EliminarPaisButton
        '
        Me.EliminarPaisButton.Location = New System.Drawing.Point(523, 275)
        Me.EliminarPaisButton.Margin = New System.Windows.Forms.Padding(2)
        Me.EliminarPaisButton.Name = "EliminarPaisButton"
        Me.EliminarPaisButton.Size = New System.Drawing.Size(145, 80)
        Me.EliminarPaisButton.TabIndex = 5
        Me.EliminarPaisButton.Text = "Eliminar"
        Me.EliminarPaisButton.UseVisualStyleBackColor = True
        '
        'LimpiarPaisButton
        '
        Me.LimpiarPaisButton.Location = New System.Drawing.Point(523, 160)
        Me.LimpiarPaisButton.Margin = New System.Windows.Forms.Padding(2)
        Me.LimpiarPaisButton.Name = "LimpiarPaisButton"
        Me.LimpiarPaisButton.Size = New System.Drawing.Size(145, 80)
        Me.LimpiarPaisButton.TabIndex = 3
        Me.LimpiarPaisButton.Text = "Limpiar"
        Me.LimpiarPaisButton.UseVisualStyleBackColor = True
        '
        'AnadirPaisButton
        '
        Me.AnadirPaisButton.Location = New System.Drawing.Point(523, 49)
        Me.AnadirPaisButton.Margin = New System.Windows.Forms.Padding(2)
        Me.AnadirPaisButton.Name = "AnadirPaisButton"
        Me.AnadirPaisButton.Size = New System.Drawing.Size(145, 80)
        Me.AnadirPaisButton.TabIndex = 1
        Me.AnadirPaisButton.Text = "Añadir"
        Me.AnadirPaisButton.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.ArtAlbumListbox)
        Me.TabPage5.Controls.Add(Me.Label16)
        Me.TabPage5.Controls.Add(Me.IdAlbumTextBox)
        Me.TabPage5.Controls.Add(Me.LimpiarAlbumButton)
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Controls.Add(Me.ArtistaAlbumComboBox)
        Me.TabPage5.Controls.Add(Me.Label7)
        Me.TabPage5.Controls.Add(Me.AnoAlbumTextBox)
        Me.TabPage5.Controls.Add(Me.Label6)
        Me.TabPage5.Controls.Add(Me.TituloAlbumTextBox)
        Me.TabPage5.Controls.Add(Me.AlbumesListBox)
        Me.TabPage5.Controls.Add(Me.EliminarAlbumButton)
        Me.TabPage5.Controls.Add(Me.ModificarAlbumButton)
        Me.TabPage5.Controls.Add(Me.AnadirAlbumButton)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage5.Size = New System.Drawing.Size(792, 397)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Albumes"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(346, 35)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 13)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "ID DEL ALBUM"
        '
        'IdAlbumTextBox
        '
        Me.IdAlbumTextBox.Location = New System.Drawing.Point(317, 54)
        Me.IdAlbumTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.IdAlbumTextBox.Name = "IdAlbumTextBox"
        Me.IdAlbumTextBox.Size = New System.Drawing.Size(145, 20)
        Me.IdAlbumTextBox.TabIndex = 17
        '
        'LimpiarAlbumButton
        '
        Me.LimpiarAlbumButton.Location = New System.Drawing.Point(537, 199)
        Me.LimpiarAlbumButton.Name = "LimpiarAlbumButton"
        Me.LimpiarAlbumButton.Size = New System.Drawing.Size(145, 81)
        Me.LimpiarAlbumButton.TabIndex = 16
        Me.LimpiarAlbumButton.Text = "Limpiar"
        Me.LimpiarAlbumButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(335, 267)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "ARTISTA DEL ALBUM"
        '
        'ArtistaAlbumComboBox
        '
        Me.ArtistaAlbumComboBox.FormattingEnabled = True
        Me.ArtistaAlbumComboBox.Location = New System.Drawing.Point(319, 288)
        Me.ArtistaAlbumComboBox.Margin = New System.Windows.Forms.Padding(2)
        Me.ArtistaAlbumComboBox.Name = "ArtistaAlbumComboBox"
        Me.ArtistaAlbumComboBox.Size = New System.Drawing.Size(146, 21)
        Me.ArtistaAlbumComboBox.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(355, 187)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "AÑO ALBUM"
        '
        'AnoAlbumTextBox
        '
        Me.AnoAlbumTextBox.Location = New System.Drawing.Point(317, 212)
        Me.AnoAlbumTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.AnoAlbumTextBox.Name = "AnoAlbumTextBox"
        Me.AnoAlbumTextBox.Size = New System.Drawing.Size(145, 20)
        Me.AnoAlbumTextBox.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(335, 109)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "TITULO DEL ALBUM"
        '
        'TituloAlbumTextBox
        '
        Me.TituloAlbumTextBox.Location = New System.Drawing.Point(316, 133)
        Me.TituloAlbumTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TituloAlbumTextBox.Name = "TituloAlbumTextBox"
        Me.TituloAlbumTextBox.Size = New System.Drawing.Size(146, 20)
        Me.TituloAlbumTextBox.TabIndex = 10
        '
        'AlbumesListBox
        '
        Me.AlbumesListBox.FormattingEnabled = True
        Me.AlbumesListBox.Location = New System.Drawing.Point(40, 34)
        Me.AlbumesListBox.Margin = New System.Windows.Forms.Padding(2)
        Me.AlbumesListBox.Name = "AlbumesListBox"
        Me.AlbumesListBox.Size = New System.Drawing.Size(140, 316)
        Me.AlbumesListBox.TabIndex = 6
        '
        'EliminarAlbumButton
        '
        Me.EliminarAlbumButton.Location = New System.Drawing.Point(537, 292)
        Me.EliminarAlbumButton.Margin = New System.Windows.Forms.Padding(2)
        Me.EliminarAlbumButton.Name = "EliminarAlbumButton"
        Me.EliminarAlbumButton.Size = New System.Drawing.Size(145, 80)
        Me.EliminarAlbumButton.TabIndex = 5
        Me.EliminarAlbumButton.Text = "Eliminar"
        Me.EliminarAlbumButton.UseVisualStyleBackColor = True
        '
        'ModificarAlbumButton
        '
        Me.ModificarAlbumButton.Location = New System.Drawing.Point(537, 102)
        Me.ModificarAlbumButton.Margin = New System.Windows.Forms.Padding(2)
        Me.ModificarAlbumButton.Name = "ModificarAlbumButton"
        Me.ModificarAlbumButton.Size = New System.Drawing.Size(145, 80)
        Me.ModificarAlbumButton.TabIndex = 3
        Me.ModificarAlbumButton.Text = "Modificar"
        Me.ModificarAlbumButton.UseVisualStyleBackColor = True
        '
        'AnadirAlbumButton
        '
        Me.AnadirAlbumButton.Location = New System.Drawing.Point(537, 4)
        Me.AnadirAlbumButton.Margin = New System.Windows.Forms.Padding(2)
        Me.AnadirAlbumButton.Name = "AnadirAlbumButton"
        Me.AnadirAlbumButton.Size = New System.Drawing.Size(145, 80)
        Me.AnadirAlbumButton.TabIndex = 1
        Me.AnadirAlbumButton.Text = "Añadir"
        Me.AnadirAlbumButton.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.NAlbumesListbox)
        Me.TabPage6.Controls.Add(Me.LimpiarCancionesButton)
        Me.TabPage6.Controls.Add(Me.Label17)
        Me.TabPage6.Controls.Add(Me.OrdenCancionTextBox)
        Me.TabPage6.Controls.Add(Me.Label12)
        Me.TabPage6.Controls.Add(Me.AlbumCancionComboBox)
        Me.TabPage6.Controls.Add(Me.Label9)
        Me.TabPage6.Controls.Add(Me.IdCancionTextBox)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.DuracionCancionTextBox)
        Me.TabPage6.Controls.Add(Me.Label11)
        Me.TabPage6.Controls.Add(Me.TituloCancionTextBox)
        Me.TabPage6.Controls.Add(Me.CancionesListBox)
        Me.TabPage6.Controls.Add(Me.EliminarCancionesButton)
        Me.TabPage6.Controls.Add(Me.ModificarCancionesButton)
        Me.TabPage6.Controls.Add(Me.AnadirCancionesButton)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage6.Size = New System.Drawing.Size(792, 397)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Canciones"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'LimpiarCancionesButton
        '
        Me.LimpiarCancionesButton.Location = New System.Drawing.Point(562, 193)
        Me.LimpiarCancionesButton.Name = "LimpiarCancionesButton"
        Me.LimpiarCancionesButton.Size = New System.Drawing.Size(145, 81)
        Me.LimpiarCancionesButton.TabIndex = 29
        Me.LimpiarCancionesButton.Text = "Limpiar"
        Me.LimpiarCancionesButton.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(331, 333)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(131, 13)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "ORDEN DE LA CANCION"
        '
        'OrdenCancionTextBox
        '
        Me.OrdenCancionTextBox.Location = New System.Drawing.Point(325, 351)
        Me.OrdenCancionTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.OrdenCancionTextBox.Name = "OrdenCancionTextBox"
        Me.OrdenCancionTextBox.Size = New System.Drawing.Size(145, 20)
        Me.OrdenCancionTextBox.TabIndex = 27
        Me.OrdenCancionTextBox.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(374, 221)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "ALBUM"
        '
        'AlbumCancionComboBox
        '
        Me.AlbumCancionComboBox.FormattingEnabled = True
        Me.AlbumCancionComboBox.Location = New System.Drawing.Point(325, 240)
        Me.AlbumCancionComboBox.Margin = New System.Windows.Forms.Padding(2)
        Me.AlbumCancionComboBox.Name = "AlbumCancionComboBox"
        Me.AlbumCancionComboBox.Size = New System.Drawing.Size(146, 21)
        Me.AlbumCancionComboBox.TabIndex = 25
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(351, 35)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 13)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "ID DE LA CANCIÓN"
        '
        'IdCancionTextBox
        '
        Me.IdCancionTextBox.Location = New System.Drawing.Point(325, 54)
        Me.IdCancionTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.IdCancionTextBox.Name = "IdCancionTextBox"
        Me.IdCancionTextBox.Size = New System.Drawing.Size(145, 20)
        Me.IdCancionTextBox.TabIndex = 23
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(348, 161)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(95, 13)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "DURACION (SEG)"
        '
        'DuracionCancionTextBox
        '
        Me.DuracionCancionTextBox.Location = New System.Drawing.Point(325, 182)
        Me.DuracionCancionTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.DuracionCancionTextBox.Name = "DuracionCancionTextBox"
        Me.DuracionCancionTextBox.Size = New System.Drawing.Size(145, 20)
        Me.DuracionCancionTextBox.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(334, 96)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(131, 13)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "TITULO DE LA CANCIÓN"
        '
        'TituloCancionTextBox
        '
        Me.TituloCancionTextBox.Location = New System.Drawing.Point(324, 118)
        Me.TituloCancionTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TituloCancionTextBox.Name = "TituloCancionTextBox"
        Me.TituloCancionTextBox.Size = New System.Drawing.Size(146, 20)
        Me.TituloCancionTextBox.TabIndex = 19
        '
        'CancionesListBox
        '
        Me.CancionesListBox.FormattingEnabled = True
        Me.CancionesListBox.Location = New System.Drawing.Point(48, 33)
        Me.CancionesListBox.Margin = New System.Windows.Forms.Padding(2)
        Me.CancionesListBox.Name = "CancionesListBox"
        Me.CancionesListBox.Size = New System.Drawing.Size(140, 329)
        Me.CancionesListBox.TabIndex = 7
        '
        'EliminarCancionesButton
        '
        Me.EliminarCancionesButton.Location = New System.Drawing.Point(562, 286)
        Me.EliminarCancionesButton.Margin = New System.Windows.Forms.Padding(2)
        Me.EliminarCancionesButton.Name = "EliminarCancionesButton"
        Me.EliminarCancionesButton.Size = New System.Drawing.Size(145, 80)
        Me.EliminarCancionesButton.TabIndex = 5
        Me.EliminarCancionesButton.Text = "Eliminar"
        Me.EliminarCancionesButton.UseVisualStyleBackColor = True
        '
        'ModificarCancionesButton
        '
        Me.ModificarCancionesButton.Location = New System.Drawing.Point(562, 102)
        Me.ModificarCancionesButton.Margin = New System.Windows.Forms.Padding(2)
        Me.ModificarCancionesButton.Name = "ModificarCancionesButton"
        Me.ModificarCancionesButton.Size = New System.Drawing.Size(145, 80)
        Me.ModificarCancionesButton.TabIndex = 3
        Me.ModificarCancionesButton.Text = "Modificar"
        Me.ModificarCancionesButton.UseVisualStyleBackColor = True
        '
        'AnadirCancionesButton
        '
        Me.AnadirCancionesButton.Location = New System.Drawing.Point(562, 18)
        Me.AnadirCancionesButton.Margin = New System.Windows.Forms.Padding(2)
        Me.AnadirCancionesButton.Name = "AnadirCancionesButton"
        Me.AnadirCancionesButton.Size = New System.Drawing.Size(145, 80)
        Me.AnadirCancionesButton.TabIndex = 1
        Me.AnadirCancionesButton.Text = "Añadir"
        Me.AnadirCancionesButton.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.LimpiarSitiosButton)
        Me.TabPage7.Controls.Add(Me.Label18)
        Me.TabPage7.Controls.Add(Me.TipoSitioTextBox)
        Me.TabPage7.Controls.Add(Me.Label19)
        Me.TabPage7.Controls.Add(Me.PaisSitioComboBox)
        Me.TabPage7.Controls.Add(Me.Label20)
        Me.TabPage7.Controls.Add(Me.IdSitioTextBox)
        Me.TabPage7.Controls.Add(Me.Label21)
        Me.TabPage7.Controls.Add(Me.NombreSitioTextBox)
        Me.TabPage7.Controls.Add(Me.SitioListBox)
        Me.TabPage7.Controls.Add(Me.AnadirSitioButton)
        Me.TabPage7.Controls.Add(Me.EliminarSitioButton)
        Me.TabPage7.Controls.Add(Me.ModificarSitioButton)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage7.Size = New System.Drawing.Size(792, 397)
        Me.TabPage7.TabIndex = 4
        Me.TabPage7.Text = "Sitios"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'LimpiarSitiosButton
        '
        Me.LimpiarSitiosButton.Location = New System.Drawing.Point(557, 190)
        Me.LimpiarSitiosButton.Name = "LimpiarSitiosButton"
        Me.LimpiarSitiosButton.Size = New System.Drawing.Size(145, 81)
        Me.LimpiarSitiosButton.TabIndex = 37
        Me.LimpiarSitiosButton.Text = "Limpiar"
        Me.LimpiarSitiosButton.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(374, 260)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(32, 13)
        Me.Label18.TabIndex = 36
        Me.Label18.Text = "TIPO"
        '
        'TipoSitioTextBox
        '
        Me.TipoSitioTextBox.Location = New System.Drawing.Point(322, 284)
        Me.TipoSitioTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TipoSitioTextBox.Name = "TipoSitioTextBox"
        Me.TipoSitioTextBox.Size = New System.Drawing.Size(145, 20)
        Me.TipoSitioTextBox.TabIndex = 35
        Me.TipoSitioTextBox.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(377, 195)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 13)
        Me.Label19.TabIndex = 34
        Me.Label19.Text = "PAIS"
        '
        'PaisSitioComboBox
        '
        Me.PaisSitioComboBox.FormattingEnabled = True
        Me.PaisSitioComboBox.Location = New System.Drawing.Point(322, 214)
        Me.PaisSitioComboBox.Margin = New System.Windows.Forms.Padding(2)
        Me.PaisSitioComboBox.Name = "PaisSitioComboBox"
        Me.PaisSitioComboBox.Size = New System.Drawing.Size(146, 21)
        Me.PaisSitioComboBox.TabIndex = 33
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(356, 71)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 13)
        Me.Label20.TabIndex = 32
        Me.Label20.Text = "ID DEL SITIO"
        '
        'IdSitioTextBox
        '
        Me.IdSitioTextBox.Location = New System.Drawing.Point(322, 90)
        Me.IdSitioTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.IdSitioTextBox.Name = "IdSitioTextBox"
        Me.IdSitioTextBox.Size = New System.Drawing.Size(145, 20)
        Me.IdSitioTextBox.TabIndex = 31
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(340, 132)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(109, 13)
        Me.Label21.TabIndex = 30
        Me.Label21.Text = "NOMBRE DEL SITIO"
        '
        'NombreSitioTextBox
        '
        Me.NombreSitioTextBox.Location = New System.Drawing.Point(321, 154)
        Me.NombreSitioTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.NombreSitioTextBox.Name = "NombreSitioTextBox"
        Me.NombreSitioTextBox.Size = New System.Drawing.Size(146, 20)
        Me.NombreSitioTextBox.TabIndex = 29
        '
        'SitioListBox
        '
        Me.SitioListBox.FormattingEnabled = True
        Me.SitioListBox.Location = New System.Drawing.Point(35, 21)
        Me.SitioListBox.Margin = New System.Windows.Forms.Padding(2)
        Me.SitioListBox.Name = "SitioListBox"
        Me.SitioListBox.Size = New System.Drawing.Size(140, 342)
        Me.SitioListBox.TabIndex = 7
        '
        'ArtAlbumListbox
        '
        Me.ArtAlbumListbox.FormattingEnabled = True
        Me.ArtAlbumListbox.Location = New System.Drawing.Point(319, 324)
        Me.ArtAlbumListbox.Margin = New System.Windows.Forms.Padding(2)
        Me.ArtAlbumListbox.Name = "ArtAlbumListbox"
        Me.ArtAlbumListbox.Size = New System.Drawing.Size(146, 69)
        Me.ArtAlbumListbox.TabIndex = 20
        '
        'NAlbumesListbox
        '
        Me.NAlbumesListbox.FormattingEnabled = True
        Me.NAlbumesListbox.Location = New System.Drawing.Point(280, 270)
        Me.NAlbumesListbox.Margin = New System.Windows.Forms.Padding(2)
        Me.NAlbumesListbox.Name = "NAlbumesListbox"
        Me.NAlbumesListbox.Size = New System.Drawing.Size(222, 56)
        Me.NAlbumesListbox.TabIndex = 31
        '
        'GestorTablas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "GestorTablas"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents AnadirSitioButton As Button
    Friend WithEvents ModificarSitioButton As Button
    Friend WithEvents EliminarSitioButton As Button
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents GestionarPaisComboBox As ComboBox
    Friend WithEvents NombreArtistaTextBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents IdArtistaTextBox As TextBox
    Friend WithEvents ArtistasListBox As ListBox
    Friend WithEvents EliminarArtistaButton As Button
    Friend WithEvents ModificarArtistaButton As Button
    Friend WithEvents AnadirArtistaButton As Button
    Friend WithEvents NombrePaisTextBox As TextBox
    Friend WithEvents IdPaisTextBox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PaisListBox As ListBox
    Friend WithEvents EliminarPaisButton As Button
    Friend WithEvents LimpiarPaisButton As Button
    Friend WithEvents AnadirPaisButton As Button
    Friend WithEvents AlbumesListBox As ListBox
    Friend WithEvents EliminarAlbumButton As Button
    Friend WithEvents ModificarAlbumButton As Button
    Friend WithEvents AnadirAlbumButton As Button
    Friend WithEvents CancionesListBox As ListBox
    Friend WithEvents EliminarCancionesButton As Button
    Friend WithEvents ModificarCancionesButton As Button
    Friend WithEvents AnadirCancionesButton As Button
    Friend WithEvents SitioListBox As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents ArtistaAlbumComboBox As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents AnoAlbumTextBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TituloAlbumTextBox As TextBox
    Friend WithEvents LimpiarArtistaButton As Button
    Friend WithEvents LimpiarAlbumButton As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents IdAlbumTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents IdCancionTextBox As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents DuracionCancionTextBox As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TituloCancionTextBox As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents AlbumCancionComboBox As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents OrdenCancionTextBox As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents TipoSitioTextBox As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents PaisSitioComboBox As ComboBox
    Friend WithEvents Label20 As Label
    Friend WithEvents IdSitioTextBox As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents NombreSitioTextBox As TextBox
    Friend WithEvents LimpiarCancionesButton As Button
    Friend WithEvents LimpiarSitiosButton As Button
    Friend WithEvents ArtAlbumListbox As ListBox
    Friend WithEvents NAlbumesListbox As ListBox
End Class
